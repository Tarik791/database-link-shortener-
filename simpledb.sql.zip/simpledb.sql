-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 13, 2020 at 09:54 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `simpledb`
--

-- --------------------------------------------------------

--
-- Table structure for table `urls`
--

CREATE TABLE `urls` (
  `id` int(11) NOT NULL,
  `url` varchar(500) NOT NULL,
  `shorturl` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `urls`
--

INSERT INTO `urls` (`id`, `url`, `shorturl`) VALUES
(2, 'https://windows.php.net/download/', 'wrA3IZRmhV3uVpoiIYOSP6nkXqExmeKaTM1R1HHZzsD9vy7mh0'),
(3, 'https://windows.php.net/download/', 'i3TxqMlCXTjcJhhEaoFUCLBXwPc5rZX5GMLRHxWd5QsPWoUgbt'),
(4, 'http://www.youtube.com', '3KfvtQMlHRFzPBSdirvwJA0n9mRJWoK8iImRh7fCMmmOKMYQuq'),
(5, 'http://www.youtube.com', 'Jwc0jjpe626HCj47cxg3R0jRacTOBU9tP92DmCxOoQgKr0jkRW'),
(6, 'https://www.youtube.com/watch?v=m8i1aHxKjBE&ab_channel=CoderSathy', 'Zlmu4BtOdXGKvzxaRCwMsHz3lFy5vGuCqNsRklct6l8QnnM6gT'),
(7, 'localhost/url/Zlmu4BtOdXGKvzxaRCwMsHz3lFy5vGuCqNsRklct6l8QnnM6gTRKKVwai05S4w', '0OVWHFRNTJERrBkSP71Xsej23AHdCWyS5GuCS7Y3m8c7hvZxDC'),
(8, 'http://www.youtube.com', 'sgLm0u3a98byZKffu9znrhtnumfXdIwFWBWYzu0ejA1VGXETV3'),
(9, 'http://www.youtube.com', 'tZDgarWesfaxIJCZllbhCj2JL4jglHqo3SiH3J6UJOhWsdQTIL'),
(10, 'http://www.youtube.com', '39V6lCmAM2ukYkVHTRw8v9wyE6xd4kLgYKC7QUQhu49yPunIoV'),
(11, 'http://www.youtube.com', 'wkfUZ4PUpn27FrZfn95OoQpXSSjqhEUo82iWDz73vDSAbFxl62'),
(12, 'http://www.youtube.com', '2sAbGul2wMB6aCjJGyMYcCRyVh6ZXPc3vjqKxjos2D1UG4HTwB'),
(13, 'http://www.youtube.com', 'EiUsoK3AMXW9vcXXNj73tPGIrLzVVaue2O4qJuaxQPBoA0HVyY'),
(14, 'http://www.youtube.com', 'b0inPRoUsh20DYzFy7E4JQjpzEIlsoRzQgPWisSXr4khI7jDz2'),
(15, 'https://windows.php.net/download/', 'XOF5V6z69uQbdlv8Ex2fuGcSOL90X4J84QdLZzAx5C4FtDeARI'),
(16, 'http://www.youtube.com', 'cg7Ff0myJLTVrI5lo3FaT4WwqOXfDYRqNcArz1p15LsBxT089r'),
(17, 'http://www.youtube.com', 'ZyHIFPrDl0AMy9WZ1oXQrQMIUFtowQsbtiNmgofBuArPNf3Y8R'),
(18, 'http://www.youtube.com', 'oBxf5WH9OOvqGoeevW9g8wAFTdu0c1sCP2AX2nRgbhFUL3NMPQ'),
(19, 'http://www.youtube.com', 'Peb3x'),
(20, 'http://www.youtube.com', 'rXuR6'),
(21, 'http://www.youtube.com', 'a3Ixg'),
(22, 'http://www.youtube.com', 'RHxFT'),
(23, 'https://windows.php.net/download/', 'Rq7aN'),
(24, 'https://windows.php.net/download/', 'ZsQwy'),
(25, 'https://windows.php.net/download/', 'kQcDo'),
(26, 'https://windows.php.net/download/', 'nOoER'),
(27, 'https://windows.php.net/download/', 'zrd1o'),
(28, 'https://windows.php.net/download/', 'ezV11'),
(29, 'https://windows.php.net/download/', 'tCDMW'),
(30, 'https://windows.php.net/download/', 'jKnG2'),
(31, 'https://windows.php.net/download/', 'wNuIO'),
(32, 'https://windows.php.net/download/', 'UAFGw'),
(33, 'https://windows.php.net/download/', 'U6yu1'),
(34, 'https://windows.php.net/download/', 'uKgop'),
(35, 'https://windows.php.net/download/', 'QaRuz'),
(36, 'https://windows.php.net/download/', 'Gxn28'),
(37, 'https://windows.php.net/download/', 'E1jYD'),
(38, 'https://windows.php.net/download/', 'MAajE'),
(39, 'https://windows.php.net/download/', 'BbSib'),
(40, 'https://windows.php.net/download/', 'wdZA5'),
(41, 'https://windows.php.net/download/', 'isfRt'),
(42, 'https://windows.php.net/download/', 'qZ4pb'),
(43, 'https://windows.php.net/download/', 'Z9QXh'),
(44, 'https://windows.php.net/download/', 'TcmIK'),
(45, 'https://windows.php.net/download/', 'kaFXA'),
(46, 'https://windows.php.net/download/', 'njxcY'),
(47, 'https://windows.php.net/download/', 'mi29S'),
(48, 'https://windows.php.net/download/', '2TVDX'),
(49, 'https://windows.php.net/download/', 'iSe7k'),
(50, 'https://windows.php.net/download/', 'z405d'),
(51, 'https://windows.php.net/download/', 'KeDr7'),
(52, 'https://windows.php.net/download/', 'cCcBD'),
(53, 'https://windows.php.net/download/', 'MfjsB'),
(54, 'https://windows.php.net/download/', 'AFDOd'),
(55, 'https://windows.php.net/download/', 'mjJ0d'),
(56, 'https://windows.php.net/download/', 'tKcS6'),
(57, 'https://windows.php.net/download/', 'csFTm'),
(58, 'https://windows.php.net/download/', 'pQyiX'),
(59, 'https://windows.php.net/download/', 'Qe0tL'),
(60, 'https://windows.php.net/download/', 'ILP1N'),
(61, 'https://windows.php.net/download/', 'so4xp'),
(62, 'https://windows.php.net/download/', 'Mtova'),
(63, 'https://windows.php.net/download/', 'QIQkr'),
(64, 'https://windows.php.net/download/', 'kyfOB'),
(65, 'https://windows.php.net/download/', 'UEiH0'),
(66, 'https://windows.php.net/download/', 'Y7EhL'),
(67, 'https://windows.php.net/download/', '6owj0'),
(68, 'https://windows.php.net/download/', 'jeSDG'),
(69, 'https://windows.php.net/download/', 'DBCfc'),
(70, 'https://windows.php.net/download/', 'd6nnX'),
(71, 'https://windows.php.net/download/', '1sjjj'),
(72, 'https://windows.php.net/download/', 'HCkKS'),
(73, 'https://windows.php.net/download/', 'gCpf9'),
(74, 'https://windows.php.net/download/', 'rqFB6'),
(75, 'https://windows.php.net/download/', 'y1Fpq'),
(76, 'https://windows.php.net/download/', 'Lz6TU'),
(77, 'https://windows.php.net/download/', 'ap6pR'),
(78, 'https://windows.php.net/download/', '4Mh8U'),
(79, 'http://www.youtube.com', 'Q1fxJ'),
(80, 'http://www.youtube.com', 'CjWjT'),
(81, 'http://www.youtube.com', 'vJYYn'),
(82, 'http://www.youtube.com', 'N90Fi'),
(83, 'http://www.youtube.com', 'xnu2l'),
(84, 'http://www.youtube.com', 'yQ7VT'),
(85, 'http://www.youtube.com', 'b9AQY'),
(86, 'http://www.youtube.com', '0CEnk'),
(87, 'http://www.youtube.com', 'iHWZJ'),
(88, 'http://www.youtube.com', 'GxhBs'),
(89, 'http://www.youtube.com', 'Da2dK'),
(90, 'http://www.youtube.com', 'MrFRK'),
(91, 'http://www.youtube.com', 'tQdQm'),
(92, 'http://www.youtube.com', 'XmYN1'),
(93, 'http://www.youtube.com', 'jrTYv'),
(94, 'http://www.youtube.com', 'vAKLq'),
(95, 'http://www.youtube.com', '4ggMI'),
(96, 'http://www.youtube.com', 'ZZurm'),
(97, 'http://www.youtube.com', 'Z4Ag6'),
(98, 'http://www.youtube.com', 'V2Aeq'),
(99, 'http://www.youtube.com', 'U2eWn'),
(100, 'http://www.youtube.com', 'b68Gb'),
(101, 'http://www.youtube.com', 'Q4XAf'),
(102, 'http://www.youtube.com', 'zmjj3'),
(103, 'http://www.youtube.com', '06gY7'),
(104, 'http://www.youtube.com', 'lsPQk'),
(105, 'http://www.youtube.com', 'q3bXy'),
(106, 'http://www.youtube.com', 'PXYFu'),
(107, 'http://www.youtube.com', '78OkN'),
(108, 'http://www.youtube.com', 'fA1hT'),
(109, 'http://www.youtube.com', 'Otwfu'),
(110, 'http://www.youtube.com', 'x962A'),
(111, 'http://www.youtube.com', 'tRI3s'),
(112, 'http://www.youtube.com', 'zuNog'),
(113, 'http://www.youtube.com', 'z8EYV'),
(114, 'http://www.youtube.com', 'Lpic9'),
(115, 'http://www.youtube.com', '1kfLD'),
(116, 'http://www.youtube.com', '92FQT'),
(117, 'http://www.youtube.com', 'T2JET'),
(118, 'http://www.youtube.com', 'LHPpg'),
(119, 'http://www.youtube.com', 'uVaQo'),
(120, 'http://www.youtube.com', 'mEYhk'),
(121, 'http://www.youtube.com', '4AdxW'),
(122, 'http://www.youtube.com', 'Xz6lp'),
(123, 'http://www.youtube.com', 'CkoQY'),
(124, 'http://www.youtube.com', 'YGtEw'),
(125, 'http://www.youtube.com', '168zY'),
(126, 'http://www.youtube.com', 'RzuZQ'),
(127, 'http://www.youtube.com', 'XEiZT'),
(128, 'http://www.youtube.com', '3n8o3'),
(129, 'http://www.youtube.com', 'mnyGo'),
(130, 'http://www.youtube.com', 'KgdYB'),
(131, 'http://www.youtube.com', 'Nu3vX'),
(132, 'http://www.youtube.com', '9yuSE'),
(133, 'http://www.youtube.com', '5f5yu'),
(134, 'http://www.youtube.com', 'VIDnN'),
(135, 'http://www.youtube.com', 'WPu33'),
(136, 'http://www.youtube.com', 'yLRVh'),
(137, 'http://www.youtube.com', 'g9fCn'),
(138, 'http://www.youtube.com', 'GkWoA'),
(139, 'http://www.youtube.com', 'UumRC'),
(140, 'http://www.youtube.com', 'qvnoc'),
(141, 'http://www.youtube.com', 'yIxDh'),
(142, 'http://www.youtube.com', 'pD5eI'),
(143, 'http://www.youtube.com', 's54lN'),
(144, 'http://www.youtube.com', 'qBhL4'),
(145, 'http://www.youtube.com', 'u4DKz'),
(146, 'http://www.youtube.com', 'CQlHL'),
(147, 'http://www.youtube.com', '4RTWa'),
(148, 'http://www.youtube.com', 'aUDUY'),
(149, 'http://www.youtube.com', 'aNLRC'),
(150, 'http://www.youtube.com', 'jcDDf'),
(151, 'http://www.youtube.com', 'RdjsD'),
(152, 'http://www.youtube.com', 'O3Il9'),
(153, 'http://www.youtube.com', '7sPep'),
(154, 'http://www.youtube.com', '3UNEI'),
(155, 'http://www.youtube.com', '4V7p2'),
(156, 'http://www.youtube.com', 'qrzMJ'),
(157, 'http://www.youtube.com', 'bXvhs'),
(158, 'http://www.youtube.com', 'FBJpo'),
(159, 'http://www.youtube.com', 'bnvGz'),
(160, 'http://www.youtube.com', 'Itbd2'),
(161, 'http://www.youtube.com', 'TVJgx'),
(162, 'http://www.youtube.com', 'dr5z8'),
(163, 'http://www.youtube.com', 'fkOWd'),
(164, 'http://www.youtube.com', 'HM6zq'),
(165, 'http://www.youtube.com', 'tdxht'),
(166, 'http://www.youtube.com', 'JsAtY'),
(167, 'http://www.youtube.com', 'iLK1k'),
(168, 'http://www.youtube.com', 'IzwUL'),
(169, 'http://www.youtube.com', 'h9dyY'),
(170, 'http://www.youtube.com', 'j3DNt'),
(171, 'http://www.youtube.com', 'jW8X8'),
(172, 'http://www.youtube.com', 'rZdmh'),
(173, 'http://www.youtube.com', 'ntIUi'),
(174, 'http://www.youtube.com', 'U4Fox'),
(175, 'http://www.youtube.com', 'tqv9R'),
(176, 'http://www.youtube.com', '64yhl'),
(177, 'http://www.youtube.com', 'BxH6D'),
(178, 'http://www.youtube.com', 'npzRT'),
(179, 'http://www.youtube.com', 'nxzHW'),
(180, 'http://www.youtube.com', '3Ru4i'),
(181, 'http://www.youtube.com', 'ycegH'),
(182, 'https://forms.office.com/Pages/ResponsePage.aspx?id=3bGz-Ior9EaZ-1z6UjJOqwVS6x3lavVNqFp2aQwZgztURFBWWUhEUFcwR1pQOVlXUUZKSk9BMkNMTy4u', 'TC3LK'),
(183, 'https://forms.office.com/Pages/ResponsePage.aspx?id=3bGz-Ior9EaZ-1z6UjJOqwVS6x3lavVNqFp2aQwZgztURFBWWUhEUFcwR1pQOVlXUUZKSk9BMkNMTy4u', '28rTQ'),
(184, 'https://www.youtube.com/watch?v=m8i1aHxKjBE&ab_channel=CoderSathy', 'se0ZU'),
(185, 'https://www.youtube.com/watch?v=m8i1aHxKjBE&ab_channel=CoderSathy', 'SO9Bv'),
(186, 'https://www.youtube.com/watch?v=m8i1aHxKjBE&ab_channel=CoderSathy', 'TNJNL');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `urls`
--
ALTER TABLE `urls`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `urls`
--
ALTER TABLE `urls`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=187;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
